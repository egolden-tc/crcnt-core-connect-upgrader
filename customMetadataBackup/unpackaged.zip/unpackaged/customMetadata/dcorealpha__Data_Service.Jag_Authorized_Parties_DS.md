<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Jag Authorized Parties DS</label>
    <protected>false</protected>
    <values>
        <field>dcorealpha__Active__c</field>
        <value xsi:type="xsd:boolean">true</value>
    </values>
    <values>
        <field>dcorealpha__Create_Source__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__CreatedDate__c</field>
        <value xsi:type="xsd:dateTime">2021-10-18T15:21:43.000Z</value>
    </values>
    <values>
        <field>dcorealpha__Delete_Source__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Description__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__LastModifiedDate__c</field>
        <value xsi:type="xsd:dateTime">2021-10-18T15:21:43.000Z</value>
    </values>
    <values>
        <field>dcorealpha__Read_Source__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Result_Number__c</field>
        <value xsi:type="xsd:string">single</value>
    </values>
    <values>
        <field>dcorealpha__Update_Source__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__isInternalMetadata__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
</CustomMetadata>
