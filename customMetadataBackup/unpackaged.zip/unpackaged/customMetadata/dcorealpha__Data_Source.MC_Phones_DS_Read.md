<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>MC Phones DS Read</label>
    <protected>false</protected>
    <values>
        <field>dcorealpha__Cache_Setting__c</field>
        <value xsi:type="xsd:string">none</value>
    </values>
    <values>
        <field>dcorealpha__Class_Name__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__CreatedDate__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Custom_Context_Provider__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Description__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__HTTP_Method__c</field>
        <value xsi:type="xsd:string">GET</value>
    </values>
    <values>
        <field>dcorealpha__Last_Modified_Date__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Mapping_Behaviour__c</field>
        <value xsi:type="xsd:string">none</value>
    </values>
    <values>
        <field>dcorealpha__Max_Cache_Age__c</field>
        <value xsi:type="xsd:double">60.0</value>
    </values>
    <values>
        <field>dcorealpha__Named_Credential__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Object_API_Name__c</field>
        <value xsi:type="xsd:string">HCM_Phone__c</value>
    </values>
    <values>
        <field>dcorealpha__Query_Long__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Query_Type__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Query__c</field>
        <value xsi:type="xsd:string">Select HCM_Phone_Number__c, HCM_Account__c from HCM_Phone__c where HCM_Account__c=&apos;{!recordId}&apos;</value>
    </values>
    <values>
        <field>dcorealpha__Record_Matching_Type__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Record_Matching__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Request_Body_Long__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Request_Body__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Request_Path__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Result_Filter__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Result_Number__c</field>
        <value xsi:type="xsd:string">multiple</value>
    </values>
    <values>
        <field>dcorealpha__Separate_Transactions__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>dcorealpha__Type__c</field>
        <value xsi:type="xsd:string">sfdc</value>
    </values>
    <values>
        <field>dcorealpha__isInternalMetadata__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
</CustomMetadata>
