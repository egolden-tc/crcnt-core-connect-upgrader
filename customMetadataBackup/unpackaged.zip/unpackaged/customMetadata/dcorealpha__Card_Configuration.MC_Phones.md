<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>MC Phones</label>
    <protected>false</protected>
    <values>
        <field>dcorealpha__Active__c</field>
        <value xsi:type="xsd:boolean">true</value>
    </values>
    <values>
        <field>dcorealpha__Adjust_Tile_Size__c</field>
        <value xsi:type="xsd:boolean">true</value>
    </values>
    <values>
        <field>dcorealpha__Blank_Value_Label__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Cancel_Button_Label__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Card_Data_Type__c</field>
        <value xsi:type="xsd:string">Multiple Records</value>
    </values>
    <values>
        <field>dcorealpha__Card_Description__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Card_Last_Modified_Date__c</field>
        <value xsi:type="xsd:dateTime">2021-10-15T18:49:37.000Z</value>
    </values>
    <values>
        <field>dcorealpha__Collapsed_By_Default__c</field>
        <value xsi:type="xsd:boolean">true</value>
    </values>
    <values>
        <field>dcorealpha__Collapsible__c</field>
        <value xsi:type="xsd:boolean">true</value>
    </values>
    <values>
        <field>dcorealpha__CreatedDate__c</field>
        <value xsi:type="xsd:dateTime">2021-10-15T18:49:37.000Z</value>
    </values>
    <values>
        <field>dcorealpha__Custom_Context_Provider__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Data_Service__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Default_Collapsed_State__c</field>
        <value xsi:type="xsd:string">data</value>
    </values>
    <values>
        <field>dcorealpha__Default_Tab__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Display_Mode__c</field>
        <value xsi:type="xsd:string">readonly</value>
    </values>
    <values>
        <field>dcorealpha__Display_Type__c</field>
        <value xsi:type="xsd:string">grid</value>
    </values>
    <values>
        <field>dcorealpha__Edit_Scope__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Enable_Pagination__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>dcorealpha__Expand_Collapse_Toggle_Position__c</field>
        <value xsi:type="xsd:string">right</value>
    </values>
    <values>
        <field>dcorealpha__Expandable_Tile__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>dcorealpha__Filter_Evaluation_Type__c</field>
        <value xsi:type="xsd:string">client</value>
    </values>
    <values>
        <field>dcorealpha__Filter_Orientation__c</field>
        <value xsi:type="xsd:string">horizontal</value>
    </values>
    <values>
        <field>dcorealpha__Footer_Behaviour__c</field>
        <value xsi:type="xsd:string">none</value>
    </values>
    <values>
        <field>dcorealpha__Footer_Collapse_Label__c</field>
        <value xsi:type="xsd:string">Less</value>
    </values>
    <values>
        <field>dcorealpha__Footer_Expand_Label__c</field>
        <value xsi:type="xsd:string">More</value>
    </values>
    <values>
        <field>dcorealpha__Header_Filter_Placeholder__c</field>
        <value xsi:type="xsd:string">Search this list...</value>
    </values>
    <values>
        <field>dcorealpha__Header_Icon__c</field>
        <value xsi:type="xsd:string">standard:account</value>
    </values>
    <values>
        <field>dcorealpha__Header_Title__c</field>
        <value xsi:type="xsd:string">MC Phones</value>
    </values>
    <values>
        <field>dcorealpha__Page_Size__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Primary_Group_All_Option_Label__c</field>
        <value xsi:type="xsd:string">All</value>
    </values>
    <values>
        <field>dcorealpha__Primary_Group_Default_Order_Logic__c</field>
        <value xsi:type="xsd:string">name ascending</value>
    </values>
    <values>
        <field>dcorealpha__Primary_Group_Label_Template__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Primary_Group_Manual_Order__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Primary_Group_Override_Tab_Order__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>dcorealpha__Primary_Group_Show_All_Option__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>dcorealpha__Primary_Group_Source_Detail__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Primary_Group_Source__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Primary_Group_Type__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Primary_Group_Value__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Save_Button_Label__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Save_Method__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Secondary_Group_All_Option_Label__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Secondary_Group_Label_Template__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Secondary_Group_Show_All_Option__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>dcorealpha__Secondary_Group_Source_Detail__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Secondary_Group_Source__c</field>
        <value xsi:type="xsd:string">None</value>
    </values>
    <values>
        <field>dcorealpha__Secondary_Group_Type__c</field>
        <value xsi:type="xsd:string">Tab</value>
    </values>
    <values>
        <field>dcorealpha__Secondary_Group_Value__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Show_Blanks_Last__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>dcorealpha__Show_Create_Header_Action__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>dcorealpha__Show_Delete_Record_Action__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>dcorealpha__Show_Detail_Row_Action__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>dcorealpha__Show_Edit_Row_Action__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>dcorealpha__Show_Filter__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>dcorealpha__Show_Footer_Summary__c</field>
        <value xsi:type="xsd:boolean">true</value>
    </values>
    <values>
        <field>dcorealpha__Show_Footer__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>dcorealpha__Show_Header_Filter__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>dcorealpha__Show_Header__c</field>
        <value xsi:type="xsd:boolean">true</value>
    </values>
    <values>
        <field>dcorealpha__Show_Refresh__c</field>
        <value xsi:type="xsd:boolean">true</value>
    </values>
    <values>
        <field>dcorealpha__Show_Standard_Actions__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>dcorealpha__Show_Summary__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>dcorealpha__Static_Footer_Text__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Status_Color__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Template__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>dcorealpha__Tile_Header__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Tile_Size__c</field>
        <value xsi:type="xsd:double">3.0</value>
    </values>
    <values>
        <field>dcorealpha__Tile_Status__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__isDefaultCard__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
</CustomMetadata>
