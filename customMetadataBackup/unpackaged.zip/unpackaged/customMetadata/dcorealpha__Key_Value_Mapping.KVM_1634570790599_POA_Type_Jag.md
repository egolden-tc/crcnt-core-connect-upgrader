<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>KVM 1634570790599 POA_Type Jag_Authorize</label>
    <protected>false</protected>
    <values>
        <field>dcorealpha__Error_Message__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Key_Type__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Key__c</field>
        <value xsi:type="xsd:string">POA_Type</value>
    </values>
    <values>
        <field>dcorealpha__Mapping_Label__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Mapping_Type__c</field>
        <value xsi:type="xsd:string">resultMappings</value>
    </values>
    <values>
        <field>dcorealpha__Operator__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Order__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Parent_Metadata_Name__c</field>
        <value xsi:type="xsd:string">Jag_Authorized_Parties_DSRead</value>
    </values>
    <values>
        <field>dcorealpha__Parent_Metadata_Type__c</field>
        <value xsi:type="xsd:string">Data_Source__mdt</value>
    </values>
    <values>
        <field>dcorealpha__Required__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>dcorealpha__Validation_Evaluation_Type__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>dcorealpha__Value_Type__c</field>
        <value xsi:type="xsd:string">Formula</value>
    </values>
    <values>
        <field>dcorealpha__Value__c</field>
        <value xsi:type="xsd:string">CONCATENATE(record.FirstName, record.LastName)</value>
    </values>
    <values>
        <field>dcorealpha__isDeleted__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
</CustomMetadata>
